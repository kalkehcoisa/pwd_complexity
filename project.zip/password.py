import itertools
import os
import random
import re
from string import ascii_lowercase as lowercase
from string import ascii_uppercase as uppercase
from string import digits
from string import punctuation
import zipfile


CUR_DIR = os.path.realpath(os.path.dirname(__file__))


def first_lengths(length: list, target: int, complexity=4) -> list:
    '''
    Returns the first combination of items that sums into `target`.

    :param length: length of the string
    :param num_items: num_items
    :returns: generated password
    '''

    numbers = list(range(1, length + 1))
    random.shuffle(numbers)
    for block in itertools.combinations_with_replacement(numbers, complexity):
        if sum(block) == target:
            return block


def make_password(length: int, complexity: int) -> str:
    '''Generate a random password with given length

    Allowed complexity levels:
        Complexity 1: only lowercase chars
        Complexity 2: Previous level plus at least 1 digit
        Complexity 3: Previous levels plus at least 1 uppercase char
        Complexity 4: Previous levels plus at least 1 punctuation char

    :param length: number of characters
    :param complexity: complexity level
    :returns: generated password
    '''
    charsets = (lowercase, digits, uppercase, punctuation)

    if complexity == 1:
        return ''.join(random.choices(lowercase, k=length))

    lengths = first_lengths(
        length=length,
        target=length,
        complexity=complexity
    )
    return ''.join(
        ''.join(random.choices(charsets[i], k=opt_len))
        for i, opt_len in enumerate(lengths)
    )


def check_password_level(password: str) -> int:
    '''Return the password complexity level

    Result levels:
        Complexity 1: If password has only lowercase chars
        Complexity 2: Previous level condition and at least 1 digit
        Complexity 3: Previous levels condition and at least 1 uppercase char
        Complexity 4: Previous levels condition and at least 1 punctuation

    Level exceptions:
        Complexity 2: password has length >= 8 chars and only lowercase chars
        Complexity 3: password has length >= 8 chars and only lowercase and digits

    :param password: password
    :returns: complexity level
    '''
    pwdlen = len(password)
    lower = len(re.findall(r'[' + lowercase + ']', password))
    total_length = lower
    complexity = 0

    # contains at least one lowercase letter
    if lower > 0:
        complexity += 1
        if total_length == pwdlen:
            # exception: length >= 8 chars and only lowercase chars
            if pwdlen >= 8:
                complexity += 1
            return complexity

        # contains at least one digit
        digs = len(re.findall(r'[' + digits + ']', password))
        total_length += digs
        if digs > 0:
            complexity += 1
            if total_length == pwdlen:
                # exception: length >= 8 chars and only lowercase and digits
                if pwdlen >= 8:
                    complexity += 1
                return complexity

            # contains at least one uppercase letter
            upper = len(re.findall(r'[' + uppercase + ']', password))
            total_length += upper
            if upper > 0:
                complexity += 1
                if total_length == pwdlen:
                    return complexity

                # contains at least one signal of punctuation
                punct = len(re.findall(r'[' + punctuation + ']', password))
                if punct > 0:
                    complexity += 1
    return complexity


def generate_and_save(orig):
    '''
    Use the function you have created to generate 12 passwords,
    3 for each complexity level (found in the file skeleton.py)
    where you should use as length, respectively: 8, 10 and 12 characters.

    Create a script to store the 12 generated passwords into a file
    (you can choose the file type).

    :param orig: the path to save the file
    '''

    with open(orig, 'w') as passwords:
        for complexity in range(1, 5):
            for length in (8, 10, 12):
                passwords.write(make_password(length, complexity) + '\n')


def read_and_save(orig, dest):
    '''
    Create a script that read the file you generated on step 3 and store the
    output for each password into a file (you can choose the file type).

    :param orig: the path to save the file
    '''
    with open(orig, 'r') as passwords:
        with open(dest, 'w') as complexities:
            for passwd in passwords.readlines():
                complexities.write(
                    str(check_password_level(passwd.strip())) + '\n'
                )


def zip_all_files(zipname):
    '''
    Compress all files (Python scripts and generated output files)
    into a single test.zip.
    '''
    with zipfile.ZipFile(zipname, 'w') as output_zip:
        for folder, subfolders, files in os.walk(CUR_DIR):
            for file in files:
                if file.endswith('.py') or file.endswith('.txt'):
                    output_zip.write(
                        os.path.join(folder, file),
                        os.path.relpath(os.path.join(folder, file), CUR_DIR),
                        compress_type=zipfile.ZIP_DEFLATED
                    )


def do_the_things():
    '''
    Runs all the code required in this task.
    '''
    orig = os.path.join(CUR_DIR, 'passwords.txt')
    dest = os.path.join(CUR_DIR, 'complexities.txt')
    zipfile = os.path.join(CUR_DIR, 'project.zip')
    generate_and_save(orig)
    read_and_save(orig, dest)
    zip_all_files(zipfile)


if __name__ == '__main__':
    do_the_things()
